import { DataTypes } from 'sequelize';

export default (sequelize) => {
  const Cita = sequelize.define('Cita', {
    fechaHora: { type: DataTypes.DATE, allowNull: false },
    motivo: { type: DataTypes.STRING, allowNull: false },
    notas: { type: DataTypes.TEXT },
    estado: { 
      type: DataTypes.ENUM('Pendiente', 'Confirmada', 'Cancelada', 'Completada'), 
      defaultValue: 'Pendiente' 
    },
    pacienteId: { type: DataTypes.INTEGER, allowNull: false },
    medicoId: { type: DataTypes.INTEGER, allowNull: false }
  }, {
    tableName: 'cita'
  });
  return Cita;
};
